<?php

require_once WPDOOM_PLUGIN_PATH . '/inc/enqueue.php';
require_once WPDOOM_PLUGIN_PATH . '/inc/display.php';